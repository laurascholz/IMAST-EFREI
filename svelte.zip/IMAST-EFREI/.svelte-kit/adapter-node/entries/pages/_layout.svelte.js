import { c as create_ssr_component } from "../../chunks/index.js";
const _layout_svelte_svelte_type_style_lang = "";
const css = {
  code: ':root:not([data-theme="dark"]){--primary:#8e24aa;--primary-hover:#7b1fa2;--primary-focus:rgba(142, 36, 170, 0.125);--primary-inverse:#FFF}nav.svelte-xje15h{display:flex;justify-content:right}li.svelte-xje15h{color:darkmagenta}strong.svelte-xje15h{color:darkmagenta}a.svelte-xje15h{color:dimgray}',
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<div class="${"container"}"><nav class="${"svelte-xje15h"}"><ul><li class="${"svelte-xje15h"}"><strong class="${"svelte-xje15h"}">COSMETIC CHECKER </strong></li></ul>
		<ul><li class="${"svelte-xje15h"}"><a href="${"/"}" class="${"svelte-xje15h"}">Home</a></li>
			<li class="${"svelte-xje15h"}"><a href="${"/about"}" class="${"svelte-xje15h"}">About</a></li>
			</ul></nav></div>

<main><div class="${"container"}">${slots.default ? slots.default({}) : ``}</div>
</main>`;
});
export {
  Layout as default
};
