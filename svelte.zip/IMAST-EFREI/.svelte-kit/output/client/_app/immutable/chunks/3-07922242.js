import{default as t}from"../components/pages/about/_page.svelte-200aa666.js";export{t as component};
