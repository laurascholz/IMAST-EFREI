import{default as t}from"../components/error.svelte-3268a886.js";export{t as component};
