import{default as t}from"../components/pages/_page.svelte-63829a5b.js";export{t as component};
