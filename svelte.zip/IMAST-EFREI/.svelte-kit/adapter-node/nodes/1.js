

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const file = '_app/immutable/components/error.svelte-3268a886.js';
export const imports = ["_app/immutable/components/error.svelte-3268a886.js","_app/immutable/chunks/index-ea45bd1e.js","_app/immutable/chunks/singletons-80d0e707.js"];
export const stylesheets = [];
export const fonts = [];
