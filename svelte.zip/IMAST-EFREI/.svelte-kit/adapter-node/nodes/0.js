

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const file = '_app/immutable/components/pages/_layout.svelte-8661a6ae.js';
export const imports = ["_app/immutable/components/pages/_layout.svelte-8661a6ae.js","_app/immutable/chunks/index-ea45bd1e.js"];
export const stylesheets = ["_app/immutable/assets/_layout-dfebb494.css"];
export const fonts = [];
