import{default as t}from"../components/pages/_layout.svelte-8661a6ae.js";export{t as component};
