

export const index = 3;
export const component = async () => (await import('../entries/pages/about/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/about/_page.svelte-200aa666.js';
export const imports = ["_app/immutable/components/pages/about/_page.svelte-200aa666.js","_app/immutable/chunks/index-ea45bd1e.js"];
export const stylesheets = ["_app/immutable/assets/_page-79677dcb.css"];
export const fonts = [];
