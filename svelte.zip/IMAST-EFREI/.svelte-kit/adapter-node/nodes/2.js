

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/_page.svelte-63829a5b.js';
export const imports = ["_app/immutable/components/pages/_page.svelte-63829a5b.js","_app/immutable/chunks/index-ea45bd1e.js"];
export const stylesheets = ["_app/immutable/assets/_page-9e303ffd.css"];
export const fonts = [];
